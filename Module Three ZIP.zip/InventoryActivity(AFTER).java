package com.example.inventorydatabase;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.snackbar.Snackbar;

import java.util.ArrayList;

/**
 * InventoryActivity (View Layer - MVVM Architecture)
 *
 * Responsibilities:
 * - UI rendering
 * - User input collection & validation
 * - Observing ViewModel state
 *
 * This class intentionally contains NO business logic or database access.
 * All data operations are delegated to the ViewModel layer.
 */
public class InventoryActivity extends AppCompatActivity {

    private InventoryViewModel viewModel;
    private InventoryAdapter adapter;
    private RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        initializeUI();
        initializeViewModel();
        observeViewModel();
        setupEventHandlers();
    }

    /**
     * Initializes RecyclerView and UI components
     */
    private void initializeUI() {
        recyclerView = findViewById(R.id.rvItems);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        adapter = new InventoryAdapter(new ArrayList<>());
        recyclerView.setAdapter(adapter);
    }

    /**
     * Initializes ViewModel (data abstraction layer)
     */
    private void initializeViewModel() {
        viewModel = new ViewModelProvider(this).get(InventoryViewModel.class);
    }

    /**
     * Observes LiveData from ViewModel
     * Ensures UI reacts to data changes asynchronously
     */
    private void observeViewModel() {

        // Observe inventory list
        viewModel.getItems().observe(this, items -> {
            adapter.updateList(items);

            if (items == null || items.isEmpty()) {
                showMessage("Inventory is empty");
            }
        });

        // Observe error messages (defensive programming)
        viewModel.getErrorMessage().observe(this, error -> {
            if (error != null && !error.isEmpty()) {
                showMessage(error);
            }
        });

        // Observe low-stock alerts (Category Three feature)
        viewModel.getLowStockEvent().observe(this, itemName -> {
            if (itemName != null) {
                showMessage("Low stock alert: " + itemName);
            }
        });
    }

    /**
     * Sets up UI event listeners
     */
    private void setupEventHandlers() {
        Button btnAdd = findViewById(R.id.btnAddItem);
        btnAdd.setOnClickListener(v -> showAddDialog());

        Button btnSearch = findViewById(R.id.btnSearchItem);
        if (btnSearch != null) {
            btnSearch.setOnClickListener(v -> showSearchDialog());
        }
    }

    /**
     * Dialog for adding new inventory item
     * Includes strong validation BEFORE data reaches database
     */
    private void showAddDialog() {

        View dialogView = LayoutInflater.from(this)
                .inflate(R.layout.dialog_add_item, null);

        EditText etName = dialogView.findViewById(R.id.etName);
        EditText etQty = dialogView.findViewById(R.id.etQty);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Add Inventory Item")
                .setView(dialogView)
                .setPositiveButton("Save", null)
                .setNegativeButton("Cancel", null)
                .create();

        dialog.setOnShowListener(d -> {
            Button btnSave = dialog.getButton(AlertDialog.BUTTON_POSITIVE);

            btnSave.setOnClickListener(v -> {

                String name = etName.getText().toString().trim();
                String qtyStr = etQty.getText().toString().trim();

                // 🔒 SECURITY: Input validation before DB interaction
                if (!isValidName(name)) {
                    etName.setError("Name must be 1–50 alphanumeric characters");
                    return;
                }

                int qty;
                try {
                    qty = qtyStr.isEmpty() ? 0 : Integer.parseInt(qtyStr);

                    if (qty < 0) {
                        etQty.setError("Quantity cannot be negative");
                        return;
                    }

                } catch (NumberFormatException e) {
                    etQty.setError("Invalid number format");
                    return;
                }

                // 🚀 Delegate to ViewModel (async, safe, decoupled)
                viewModel.addItem(name, qty);

                showMessage("Item added successfully");
                dialog.dismiss();
            });
        });

        dialog.show();
    }

    /**
     * Search dialog using optimized lookup (Binary Search via ViewModel)
     */
    private void showSearchDialog() {

        EditText input = new EditText(this);
        input.setHint("Enter item name");

        new AlertDialog.Builder(this)
                .setTitle("Search Inventory")
                .setView(input)
                .setPositiveButton("Search", (dialog, which) -> {

                    String query = input.getText().toString().trim();

                    if (!isValidName(query)) {
                        showMessage("Invalid search input");
                        return;
                    }

                    Item result = viewModel.searchItem(query);

                    if (result != null) {
                        showMessage("Found: " + result.name + " (Qty: " + result.quantity + ")");
                    } else {
                        showMessage("Item not found");
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    /**
     * Displays consistent UI feedback
     * Uses Snackbar instead of Toast for better UX
     */
    private void showMessage(String message) {
        Snackbar.make(recyclerView, message, Snackbar.LENGTH_SHORT).show();
    }

    /**
     * Regex-based validation (security + data integrity)
     */
    private boolean isValidName(String name) {
        return name != null && name.matches("^[a-zA-Z0-9 ]{1,50}$");
    }
}