package com.example.inventorydatabase;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import java.util.*;

/**
 * Enhanced Repository with:
 * - Defensive programming
 * - Input validation
 * - Sorting (for binary search)
 * - HashMap caching
 */
public class InventoryRepository {

    private static final String TAG = "InventoryRepository";

    private final DBHelper dbHelper;

    // 🔥 In-memory cache for fast lookup
    private final Map<Integer, Item> itemCache = new HashMap<>();

    public InventoryRepository(Context context) {
        this.dbHelper = new DBHelper(context.getApplicationContext());
    }

    /**
     * Get all items (sorted + cached)
     */
    public List<Item> getAllItems() {
        List<Item> items = new ArrayList<>();
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        try (Cursor cursor = db.query(
                DBHelper.T_ITEMS,
                null,
                null,
                null,
                null,
                null,
                DBHelper.C_ITEM_NAME + " ASC" // sorted from DB
        )) {

            itemCache.clear();

            if (cursor != null && cursor.moveToFirst()) {
                do {
                    Item item = mapCursorToItem(cursor);
                    items.add(item);

                    // cache by ID
                    itemCache.put(item.id, item);

                } while (cursor.moveToNext());
            }

        } catch (Exception e) {
            Log.e(TAG, "Error fetching items", e);
        }

        return items;
    }

    /**
     * 🔍 Binary Search (requires sorted list)
     */
    public Item findItemByName(List<Item> sortedItems, String target) {
        if (target == null || sortedItems == null) return null;

        int left = 0;
        int right = sortedItems.size() - 1;

        while (left <= right) {
            int mid = (left + right) / 2;
            Item midItem = sortedItems.get(mid);

            int compare = midItem.name.compareToIgnoreCase(target);

            if (compare == 0) {
                return midItem;
            } else if (compare < 0) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }

        return null;
    }

    /**
     * ⚡ Fast lookup using HashMap cache
     */
    public Item getItemByIdFast(int id) {
        return itemCache.get(id);
    }

    /**
     * Create item with validation
     */
    public long createItem(String name, int qty) {
        if (!isValidName(name)) {
            Log.w(TAG, "Invalid item name");
            return -1;
        }

        SQLiteDatabase db = dbHelper.getWritableDatabase();

        try {
            ContentValues values = new ContentValues();
            values.put(DBHelper.C_ITEM_NAME, name.trim());
            values.put(DBHelper.C_ITEM_QTY, Math.max(0, qty));

            long id = db.insert(DBHelper.T_ITEMS, null, values);

            // update cache
            if (id != -1) {
                itemCache.put((int) id, new Item((int) id, name, qty));
            }

            return id;

        } catch (Exception e) {
            Log.e(TAG, "Error inserting item", e);
            return -1;
        }
    }

    /**
     * Update quantity safely
     */
    public boolean updateQuantity(int id, int newQty) {
        if (id <= 0) return false;

        SQLiteDatabase db = dbHelper.getWritableDatabase();

        try {
            ContentValues values = new ContentValues();
            values.put(DBHelper.C_ITEM_QTY, Math.max(0, newQty));

            int rows = db.update(
                    DBHelper.T_ITEMS,
                    values,
                    DBHelper.C_ITEM_ID + "=?",
                    new String[]{String.valueOf(id)}
            );

            // update cache
            if (rows == 1 && itemCache.containsKey(id)) {
                itemCache.get(id).quantity = newQty;
            }

            return rows == 1;

        } catch (Exception e) {
            Log.e(TAG, "Error updating item", e);
            return false;
        }
    }

    /**
     * Delete item safely
     */
    public boolean deleteItem(int id) {
        if (id <= 0) return false;

        SQLiteDatabase db = dbHelper.getWritableDatabase();

        try {
            int rows = db.delete(
                    DBHelper.T_ITEMS,
                    DBHelper.C_ITEM_ID + "=?",
                    new String[]{String.valueOf(id)}
            );

            // remove from cache
            if (rows == 1) {
                itemCache.remove(id);
            }

            return rows == 1;

        } catch (Exception e) {
            Log.e(TAG, "Error deleting item", e);
            return false;
        }
    }

    /**
     * 🧹 Input validation (Regex-based)
     */
    private boolean isValidName(String name) {
        return name != null && name.matches("^[a-zA-Z0-9 ]{1,50}$");
    }

    /**
     * Helper method
     */
    private Item mapCursorToItem(Cursor cursor) {
        int id = cursor.getInt(cursor.getColumnIndexOrThrow(DBHelper.C_ITEM_ID));
        String name = cursor.getString(cursor.getColumnIndexOrThrow(DBHelper.C_ITEM_NAME));
        int qty = cursor.getInt(cursor.getColumnIndexOrThrow(DBHelper.C_ITEM_QTY));

        return new Item(id, name, qty);
    }
}